<section id="maincontent">
    <div class="container">
      <div class="row">
        <div class="span12">
          <div class="tagline centered">
            <div class="row">
              <div class="span12">
                <div class="tagline_text">
                    <br/>
                  <h2>Sign-Up Success</h2>
                  <p>
                    Your new acccount has been added. Please <a href="<?php echo base_url() . 'index.php/welcome/login' ;?>">login</a>.
                  </p>
                </div>
                </div>
              </div>
            </div>
          </div>
          <!-- end tagline -->
        </div>
      </div>
    </div>
  </section>
