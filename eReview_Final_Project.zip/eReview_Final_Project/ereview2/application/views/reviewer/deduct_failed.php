<section id="maincontent">
  <div class="container">
    <div class="row">
      <div class="span12">
        <div class="tagline centered">
          <div class="row">
            <div class="span12">
              <div class="tagline_text">
                <br />
                <h2>Transfer Failed</h2>
                <p>
                  Uh! Oh! Your requested is over than your credits, please request bellow or maximumm that available on your credits! .
                </p>
                <p>
                  <a href="<?php echo base_url() . 'index.php/reviewerCtl/deductFund' ?>" class="btn btn-primary btn-lg disabled" role="button" aria-disabled="true">Back to Deduct Fund</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- end tagline -->
    </div>
  </div>
  </div>
</section>