<section id="maincontent">
  <div class="container">
    <div class="row">
      <div class="span12">
        <div class="tagline centered">
          <div class="row">
            <div class="span12">
              <div class="tagline_text">
                <br />
                <h2>UPLOAD SUCCESS!</h2>
                <p>
                  Hooray! Your job is done, please wait for receive your credits.
                </p>
                <p>
                  Let's check another new assignment for receive more credits.
                </p>
                <p>
                  <a href="<?php echo base_url() . 'index.php/reviewerCtl/taskrequest' ?>" class="btn btn-primary btn-lg disabled" role="button" aria-disabled="true">New Assignment</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- end tagline -->
    </div>
  </div>
  </div>
</section>