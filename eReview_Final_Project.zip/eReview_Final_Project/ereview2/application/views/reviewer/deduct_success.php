<section id="maincontent">
  <div class="container">
    <div class="row">
      <div class="span12">
        <div class="tagline centered">
          <div class="row">
            <div class="span12">
              <div class="tagline_text">
                <br />
                <h2>Transfer Success</h2>
                <p>
                  Hooray! Your money has been transfered to your Bank Account.
                </p>
                <p>
                  <a href="<?php echo base_url() . 'index.php/reviewerCtl/index' ?>" class="btn btn-primary btn-lg disabled" role="button" aria-disabled="true">Back to Home</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- end tagline -->
    </div>
  </div>
  </div>
</section>