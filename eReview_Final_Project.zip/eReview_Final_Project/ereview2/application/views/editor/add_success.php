<section id="maincontent">
  <div class="container">
    <div class="row">
      <div class="span12">
        <div class="tagline centered">
          <div class="row">
            <div class="span12">
              <div class="tagline_text">
                <br />
                <h2>Make an assingment to your reviewer Success!</h2>
                <p>
                  Please wait for the confirmation about your task:)
                </p>
                <p>
                  <a href="<?php echo base_url() . 'index.php/editorCtl/viewTask' ?>" class="btn btn-secondary btn-lg disabled" role="button" aria-disabled="true">View Task</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- end tagline -->
    </div>
  </div>
  </div>
</section>