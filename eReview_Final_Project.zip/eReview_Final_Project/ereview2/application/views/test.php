<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
<head>
<title>CodeIgniter Tutorial</title>
</head>
<body>

    <h1>Title: <?php echo $title; ?></h1>
	<em>&copy; 2015</em>
</body>
</html>